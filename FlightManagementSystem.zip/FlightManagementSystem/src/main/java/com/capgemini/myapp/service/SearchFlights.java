package com.capgemini.myapp.service;

import com.capgemini.myapp.dto.*;
import java.math.BigInteger;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.time.*;

public class SearchFlights {
	
	Scanner scan = new Scanner(System.in);
	
//	LocalDate myDate = LocalDate.of(2020, 03, 01);
	
		
	public SearchFlights(){
		
		System.out.println("\nSearch Your Flights\n");
		
		List<ScheduledFlight> listOfFlights = new ArrayList<ScheduledFlight>();
		
		listOfFlights.add(new ScheduledFlight(

				new Flight(
						new BigInteger("112233"),
						"SJ223",
						"SpiceJet",
						new Integer(520)
						),
				new Integer(500),
				new Schedule(
						new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
						new Airport("Chhatrapati Shivaji Airport", "MMB2342", "Mumbai"),
						LocalDate.of(2020, 03, 01),
						LocalDate.of(2020, 03, 02)
						)
				
				));
		
/*		listOfFlights.add(new ScheduledFlight(new Flight(new BigInteger("112244"), "Vistara"), 2022));
		listOfFlights.add(new ScheduledFlight(new Flight(new BigInteger("112255"), "Emirates"), 2011));
		listOfFlights.add(new ScheduledFlight(new Flight(new BigInteger("112266"), "Indigo"), 2022));
		listOfFlights.add(new ScheduledFlight(new Flight(new BigInteger("112277"), "Qatar"), 2011));
		listOfFlights.add(new ScheduledFlight(new Flight(new BigInteger("112288"), "GoAir"), 2022));
*/				
		System.out.print("Schedule Id\tFlight No.\tFlight Model \n");
		System.out.println("----------------------------------------------------------");
		
		for(ScheduledFlight temp : listOfFlights) {
			
			if(temp.getScheduleId()!=112200) {
				System.out.print(temp.getSchedule().getArrivalTime() + "       \t");
				System.out.print(temp.getSchedule().getDepartureTime() + "       \t");
				System.out.print(temp.getFlight().getFlightNumber() + "    \t");
				System.out.print(temp.getFlight().getFlightModel() + "\n");
			}
			
			else {
				System.out.print("No Flights Available");
			}
		}
		
		System.out.print("\nEnter Flight No. to Book: ");
		//int userFlightNumber  = scan.nextInt();
		
		System.out.println("\nBooking Details:- \n1.\n2.\n3.\n4.");
		
		System.out.print("\nConfirm Booking? yes/no : ");
		String confirmBooking = new String();
		confirmBooking = scan.nextLine();
		
		if(confirmBooking.equals("yes")) {
			System.out.println(">> Booking Confirmed");
		}
		
		else {
			System.out.println(">> Booking Cancelled");
		}
	}

}
