package com.capgemini.myapp.dto;

public class Main {
	
	public static void main(String[] args) {
		
		System.out.println("\t\t\t\t  _______________________________\n");
		System.out.println("\t\t\t\t|    Welcome to Flight Booking    |");
		System.out.println("\t\t\t\t  _______________________________\n\n");

		new LogIn();
		
	}

}
