package com.capgemini.myapp.service;

import com.capgemini.myapp.dto.*;
import java.math.BigInteger;

public class ScheduleFlightServicesImpl {
	
	public void scheduleFlight(ScheduledFlight scheduledFlight) {
		//ScheduledFlight
		//Schedules a flight alongwith its timings, locations and capacity
	}

	public void viewScheduledFlights(Airport a1, Airport a2, LocalDate localDate) {
		//List<ScheduledFlight>
		//Returns a list of flights between two airports on a specified date.
	}
	
	public void viewScheduledFlights(BigInteger bigInteger) {
		//Flight
		//Returns a list of a scheduled flight identifiable by flight number.
	}

	public void viewScheduledFlight() {
		//List<ScheduledFlight>
		//Shows all the details and status of all flights.
	}

	
	public void modifyScheduledFlight(Flight flight, Schedule schedule, Integer integer) {
		//ScheduledFlight
		//Modifies the details of a scheduled flight.
	}
	
	public void deleteScheduledFlight(BigInteger bigInteger) {
		//void
		//Removes a flight from the available flights.
	}
	
	public void validateScheduledFlight(ScheduledFlight scheduledFlight) {
		//void
		//Validates the attributes of a scheduled Flight.
	}

}
