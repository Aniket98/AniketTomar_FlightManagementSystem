package com.capgemini.myapp.dao;

import com.capgemini.myapp.dto.*;
import java.math.BigInteger;

public class UserDaoImpl {
	
	private List<User> userList;
	
	public void addUser(User user) {
		//UserAdds a new user.
	}
	
	public void viewUser(BigInteger bigInteger) {
		//User
		//Shows the details of a user identifiable by the user id.
	}
	
	public void viewUser() {
		//List<User>
		//Shows the details of all users.
	}
	
	public void updateUser(User user) {
		//User
		//Updates the details of a user.
	}
	
	public void deleteUser(BigInteger bigInteger) {
		//void
		//Removes a user as per the user id.
	}

}
