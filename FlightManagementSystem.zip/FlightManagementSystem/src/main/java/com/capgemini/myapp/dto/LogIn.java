package com.capgemini.myapp.dto;

import com.capgemini.myapp.service.SearchFlights;
import java.util.Scanner;
import java.io.*;

public class LogIn {
	
	String username;
	String password;
	
	Scanner scan = new Scanner(System.in);

//Constructor	
	LogIn(){

/*		//Serializing User Credentials
		try{

			Credentials user1 = new Credentials("user", "pass");
			
			FileOutputStream file = new FileOutputStream("userCredentialsFile.txt");
			ObjectOutputStream out = new ObjectOutputStream(file);
			
			out.writeObject(user1);
			out.flush();
			
			System.out.println("Successfully Serialized User Credentials");

		}
		
		catch(IOException ex) {
			System.out.println("IOException is caught");
		}
*/

		//De-serializing User Credentials
		try{

			Credentials user1 = null;
			
			FileInputStream file = new FileInputStream("userCredentialsFile.txt");
			ObjectInputStream in = new ObjectInputStream(file);
			
			user1 = (Credentials)in.readObject();
			
			in.close();
			file.close();
			
			this.username = user1.getUsername();
			this.password = user1.getPassword();

			System.out.println("____________________________ Successfully De-Serialized User Credentials ____________________________\n\n");

		}
				
		catch(IOException ex) {
			System.out.println("IOException is caught");
		}

		catch(ClassNotFoundException ex) {
			System.out.println("IOException is caught");
		}

//Login Screen - Enter and verify login credentials
		
		System.out.print(">> Username: ");
		String username = new String();
		username = scan.nextLine();
	
		System.out.print(">> Password: ");
		String password = new String();
		password = scan.nextLine();
		
		if(this.username.equals(username) && this.password.equals(password)) {
			System.out.println("\nLogin Successful!");
			System.out.println("\n___________________________________");
			
			//Moving to next Search Flight screen
			System.out.println("\nWelcome " + username + "\n");
			System.out.println("1 - Book Flight");
			System.out.println("2 - Search Flights");
			System.out.println("3 - Cancel Booking" + "\n");
			
			System.out.print("Select Option: ");
			int option = scan.nextInt();
			
			System.out.println("___________________________________");

			
			//Select an option
			switch (option) {
			
				case 1:
					new Booking(); //setup
					break;
					
				case 2:
					new SearchFlights();
					break;
				
				case 3:
					new Booking(); //cancel
					break;
					
				default:
					System.out.println("Incorrect Selection. Please Try Again.");
			
			}
		}
		
		else {
			System.out.println("\nIncorrect Id or Password.");
		}
	
	}

}
