package com.capgemini.myapp.service;

import com.capgemini.myapp.dto.*;

public class FlightServiceImpl {
	
	public void addFlight(Flight flight) {
		//Adds a new flight which can be scheduled
	}
	
	public void modifyFlight(Flight flight) {
		//Flight
		//Modify the details of a flight
	}
	
	public void viewFlight(BigInteger bigInteger) {
		//Flight
		//Shows the details of a flight specified by the flight number
	}
	
	public void viewFlight() {
		//List<Flight>
		//View the details of a flight
	}
	
	public void deleteFlight(BigInteger bigInteger) {
		//void
		//Removes a flight
	}
	
	public void validateFlight(Flight flight) {
		//void
		//Validates the attributes of a flight
	}

}
