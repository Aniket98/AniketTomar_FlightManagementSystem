package com.capgemini.myapp.service;

import com.capgemini.myapp.dto.*;

public class AirportServiceImpl {
	
	public void viewAirport() {
		//List<Airport>
		//Returns the list of all airports.
	}
	
	public void viewAirport(String string) {
		//Airport
		//Returns the details of an airport identifiable by the airport code.
	}

}
