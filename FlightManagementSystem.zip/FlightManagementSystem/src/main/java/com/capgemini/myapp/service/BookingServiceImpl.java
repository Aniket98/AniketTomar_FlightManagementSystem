package com.capgemini.myapp.service;

import com.capgemini.myapp.dto.*;

public class BookingServiceImpl {
	
	public void addBooking(Booking booking) {
		//Booking
		//Creates a new booking
	}
	
	public void modifyBooking(Booking booking) {
		//Modifies a previous booking.
		//All information related to the booking except the
		//booking the booking id can be modified
	}
	
	public void viewBooking(BigInteger bigInteger) {
		//List<Booking>
		//Retrieves a booking made by user based on booking id
	}
	
	public void viewBooking() {
		//List<Booking>
		//Retrieves a list of all the bookings made
	}
	
	public void deleteBooking(BigIngteger bigInteger) {
		//void
		//Details a previous booking identifiable by the 'booking id'
	}
	
	public void validateBooking(Booking) {
		//void
		//Validates the attributes of a booking
	}
	
	public void validatePassenger(Passenger passenger) {
		//void
		//Validates the attributes of a passenger
	}

}
