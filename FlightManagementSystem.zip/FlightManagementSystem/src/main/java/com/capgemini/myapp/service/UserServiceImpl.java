package com.capgemini.myapp.service;

import com.capgemini.myapp.dto.*;

public class UserServiceImpl {
	
	public void addUser(User user) {
		//User
		//Adds a new user
	}
	
	public void viewUser(BigInteger bigInteger) {
		//User
		//Show the details of user identifiable by user id
	}
	
	public void viewUser() {
		//List<User>
		//Shows the details of a user
	}
	
	public void updateUser(User user) {
		//User
		//Updates the details of a user
	}
	
	public void deleteUser(User user) {
		//void
		//Removes a user as per the user id
	}
	
	public void validateUser(User user) {
		//void
		//Validates the attributes of a user
	}

}
